
# Lab05 - submission

Everything you need to know about my submission.
```
Name: Shantanu Kumar Rahut
Matriculation Number: 7015438

```

## Environment and other information

To run this , you **might** need following Environment

`Operating System: Windows 10`

`Python 3.9.6`

### Packages you might need
```
import sys
import csv
import spacy
```
Download anything that you don't have already. And you can also find
**requirements.txt** file to help you with installing packages.

